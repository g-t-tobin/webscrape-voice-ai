# VoiceBot with Django + Channels + Whisper + GPT-4
Run with `podman-compose up --build`
