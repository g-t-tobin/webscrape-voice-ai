#!/usr/bin/env python
print('placeholder manage.py')